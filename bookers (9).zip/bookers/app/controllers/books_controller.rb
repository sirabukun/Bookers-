class BooksController < ApplicationController
  def index
    @books = Book.all  # 一覧表示用
    @book = Book.new  # 投稿用
  end

  def create
   @book=Book.new(books_params)
    if @book.save
      redirect_to book_path(@book.id), notice:'Book was successfully created.'
    else
      @books = Book.all  # 一覧表示用
      render :index
    end
  end

  def show
    @book=Book.find(params[:id])
  end

  def edit
    @book=Book.find(params[:id])
  end

  def update
    @book = Book.find(params[:id])
    if @book.update(books_params)
      redirect_to book_path(@book.id), notice:'Book was successfully updated.'
    else
      render :edit
    end
  end

  def destroy
      book = Book.find(params[:id])  # データ（レコード）を1件取得
    book.destroy  # データ（レコード）を削除
    redirect_to books_path  # 投稿一覧画面へリダイレクト
  end

  private
  # ストロングパラメータ
  def books_params
    params.require(:book).permit(:title, :body)
  end
end
