require 'test_helper'

class BooksControllerControllerTest < ActionDispatch::IntegrationTest
  test "should get new" do
    get books_controller_new_url
    assert_response :success
  end

end
